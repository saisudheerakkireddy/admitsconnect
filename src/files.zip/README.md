# Gradient Background Component

A production-ready React component for creating beautiful mesh gradient backgrounds with blurred blob effects. Designed based on the AdmitsConnect design system.

## 🎨 Visual Effect Overview

This component creates a **mesh gradient / aurora effect** - soft, blurred gradient blobs positioned at strategic points to create an ethereal, modern aesthetic. The effect is achieved through:

1. **Radial Gradients** - Each blob is a radial gradient that fades to transparent
2. **CSS Blur Filter** - Heavy blur (60-100px) creates the soft, diffused look
3. **Strategic Positioning** - Blobs are positioned at corners and edges
4. **Layered Opacity** - Multiple semi-transparent layers blend together

## 📦 Installation

Copy the components folder to your project:

```
src/
└── components/
    └── GradientBackground/
        ├── index.ts
        ├── GradientBackground.tsx
        ├── GradientBackgroundTailwind.tsx
        ├── GlassCard.tsx
        └── gradient-background.css
```

## 🚀 Quick Start

### Basic Usage (Tailwind Version)

```tsx
import { GradientBackgroundTailwind } from './components/GradientBackground';

function MyPage() {
  return (
    <GradientBackgroundTailwind variant="white">
      <div className="p-6">
        <h1>Your Content Here</h1>
      </div>
    </GradientBackgroundTailwind>
  );
}
```

### With Glass Cards

```tsx
import { 
  GradientBackgroundTailwind, 
  GlassCardTailwind 
} from './components/GradientBackground';

function CountrySelection() {
  return (
    <GradientBackgroundTailwind variant="white">
      <div className="p-6 max-w-md mx-auto">
        <h1 className="text-2xl font-bold mb-6">Choose Your Country</h1>
        
        <div className="grid grid-cols-3 gap-4">
          <GlassCardTailwind hoverable className="text-center py-4">
            🇺🇸 USA
          </GlassCardTailwind>
          <GlassCardTailwind hoverable className="text-center py-4">
            🇬🇧 UK
          </GlassCardTailwind>
          <GlassCardTailwind hoverable className="text-center py-4">
            🇨🇦 Canada
          </GlassCardTailwind>
        </div>
      </div>
    </GradientBackgroundTailwind>
  );
}
```

## 🎭 Variants

### Variant 1: `white`
**Use for:** Country Selection, Study Area screens, Selection interfaces

- **Background:** Pure white (#FFFFFF)
- **Blobs:** Cyan and pink blurred circles
- **Effect:** Light, airy, professional feel

```tsx
<GradientBackgroundTailwind variant="white">
  {/* Content */}
</GradientBackgroundTailwind>
```

### Variant 2: `pastel`
**Use for:** Form screens, Thank You page, Information pages

- **Background:** Gradient from purple → cyan → mint green
- **Blobs:** Purple, teal, and pink accents
- **Effect:** Soft, warm, inviting feel

```tsx
<GradientBackgroundTailwind variant="pastel">
  {/* Content */}
</GradientBackgroundTailwind>
```

## 🔧 Component API

### GradientBackground (Full Control)

```tsx
interface GradientBackgroundProps {
  variant?: 'white' | 'pastel';
  children: React.ReactNode;
  className?: string;
  minHeight?: string;
  customBlobs?: BlobConfig[];
  showGradient?: boolean;
}
```

### GradientBackgroundTailwind (Simplified)

```tsx
interface GradientBackgroundTailwindProps {
  variant?: 'white' | 'pastel';
  children: React.ReactNode;
  className?: string;
}
```

### GlassCard

```tsx
interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  blur?: 'subtle' | 'medium' | 'strong';
  opacity?: number; // 0.0 - 1.0
  border?: 'none' | 'light' | 'gradient';
  rounded?: string;
  padding?: string;
  hoverable?: boolean;
  onClick?: () => void;
}
```

## 🎨 Customization

### Custom Blobs

```tsx
import { GradientBackground, BlobConfig } from './components/GradientBackground';

const myCustomBlobs: BlobConfig[] = [
  {
    id: 'custom-1',
    color: 'rgba(255, 100, 100, 0.4)', // Red
    width: 300,
    height: 300,
    top: '-50px',
    right: '-50px',
    blur: 80,
    opacity: 0.5,
  },
  {
    id: 'custom-2',
    color: 'rgba(100, 100, 255, 0.4)', // Blue
    width: 250,
    height: 250,
    bottom: '-50px',
    left: '-50px',
    blur: 70,
    opacity: 0.5,
  },
];

function MyCustomPage() {
  return (
    <GradientBackground customBlobs={myCustomBlobs}>
      {/* Content */}
    </GradientBackground>
  );
}
```

### CSS Variables

Include `gradient-background.css` and customize via CSS variables:

```css
:root {
  /* Change blob colors */
  --blob-cyan: rgba(0, 200, 255, 0.5);
  --blob-pink: rgba(255, 100, 150, 0.5);
  
  /* Adjust blur intensity */
  --blur-medium: 70px;
  --blur-strong: 90px;
  
  /* Glassmorphism */
  --glass-bg: rgba(255, 255, 255, 0.8);
}
```

## 📱 Responsive Behavior

The component is mobile-first and works at all screen sizes:

- **Mobile (< 768px):** Blur reduced to 40px for performance
- **Small screens (< 393px):** Blur further reduced to 30px
- **Desktop:** Full blur effects applied

## ♿ Accessibility

- Blobs are marked with `aria-hidden="true"` (decorative only)
- Supports `prefers-reduced-motion` - animations disabled when preferred
- High contrast mode support - blobs become more subtle
- Print styles - gradients hidden for clean printing

## 🌐 Browser Support

| Browser | Support | Notes |
|---------|---------|-------|
| Chrome | ✅ Full | |
| Firefox | ✅ Full | |
| Safari | ✅ Full | Uses -webkit-backdrop-filter |
| Edge | ✅ Full | |
| iOS Safari | ✅ Full | Uses -webkit-backdrop-filter |
| Chrome Android | ✅ Full | |
| IE11 | ⚠️ Fallback | Solid backgrounds, no blur |

### Fallbacks

The CSS includes automatic fallbacks:
- Browsers without `backdrop-filter`: Solid white glassmorphism
- Browsers without `filter: blur()`: Reduced opacity blobs

## ⚡ Performance Tips

1. **Avoid nesting gradients:** Don't put a GradientBackground inside another
2. **Use fixed dimensions:** Blobs use fixed px values for consistency
3. **Limit blob count:** 3-5 blobs is optimal; more impacts performance
4. **Consider static variant:** Animations disabled by default for performance

## 📁 File Structure

```
GradientBackground/
├── index.ts                      # Barrel exports
├── GradientBackground.tsx        # Main component (inline styles)
├── GradientBackgroundTailwind.tsx # Tailwind-optimized version
├── GlassCard.tsx                 # Glassmorphism card component
└── gradient-background.css       # Optional CSS utilities & fallbacks
```

## 🎯 Design Tokens

### Colors (from Figma)

| Token | Value | Usage |
|-------|-------|-------|
| `--blob-cyan` | `rgba(56, 211, 240, 0.45)` | Primary cyan blob |
| `--blob-pink` | `rgba(255, 150, 200, 0.5)` | Primary pink blob |
| `--blob-purple` | `rgba(200, 162, 200, 0.5)` | Pastel purple blob |
| `--blob-teal` | `rgba(150, 220, 220, 0.5)` | Pastel teal blob |
| `--gradient-pastel-start` | `#E8D5E8` | Pastel gradient start |
| `--gradient-pastel-mid` | `#D5E8E8` | Pastel gradient middle |
| `--gradient-pastel-end` | `#C5F0E8` | Pastel gradient end |

### Blur Values

| Token | Value | Usage |
|-------|-------|-------|
| `--blur-subtle` | `40px` | Subtle blur effects |
| `--blur-medium` | `60px` | Standard blob blur |
| `--blur-strong` | `80px` | Strong blur for larger blobs |
| `--blur-heavy` | `100px` | Maximum blur intensity |

## 📖 Examples by Screen Type

### Country Selection
```tsx
<GradientBackgroundTailwind variant="white" />
```

### Study Area Selection
```tsx
<GradientBackgroundTailwind variant="white" />
```

### Form Pages
```tsx
<GradientBackgroundTailwind variant="pastel" />
```

### Thank You Page
```tsx
<GradientBackgroundTailwind variant="pastel" />
```

## 🔗 Related Resources

- [CSS backdrop-filter](https://developer.mozilla.org/en-US/docs/Web/CSS/backdrop-filter)
- [CSS filter: blur()](https://developer.mozilla.org/en-US/docs/Web/CSS/filter-function/blur)
- [Tailwind CSS](https://tailwindcss.com/)
