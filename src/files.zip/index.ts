/**
 * GradientBackground Components
 * 
 * Export all gradient-related components and utilities
 */

// Main Components
export { GradientBackground } from './GradientBackground';
export type { 
  GradientBackgroundProps, 
  GradientVariant, 
  BlobConfig 
} from './GradientBackground';

// Tailwind-optimized version
export { GradientBackgroundTailwind } from './GradientBackgroundTailwind';
export type { GradientBackgroundTailwindProps } from './GradientBackgroundTailwind';

// Glass Card Components
export { GlassCard, GlassCardTailwind } from './GlassCard';
export type { GlassCardProps, GlassCardTailwindProps } from './GlassCard';

// Default export
export { default } from './GradientBackground';
