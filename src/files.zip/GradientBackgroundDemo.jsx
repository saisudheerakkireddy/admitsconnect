import { useState } from 'react';

// ============================================================================
// GRADIENT BACKGROUND COMPONENT
// ============================================================================

type GradientVariant = 'white' | 'pastel';

interface GradientBackgroundProps {
  variant?: GradientVariant;
  children: React.ReactNode;
}

const GradientBackground = ({ variant = 'white', children }: GradientBackgroundProps) => {
  const isPastel = variant === 'pastel';

  return (
    <div 
      className="relative min-h-screen overflow-hidden"
      style={{
        background: isPastel 
          ? 'linear-gradient(to bottom, #E8D5E8 0%, #D5E8E8 50%, #C5F0E8 100%)'
          : '#FFFFFF'
      }}
    >
      {/* Blob Container */}
      <div className="absolute inset-0 pointer-events-none">
        {isPastel ? (
          <>
            {/* Pastel Variant Blobs */}
            <div
              className="absolute rounded-full"
              style={{
                width: 250, height: 250,
                top: 75, right: -50,
                background: 'radial-gradient(circle, rgba(200, 162, 200, 0.5) 0%, transparent 70%)',
                filter: 'blur(80px)',
              }}
            />
            <div
              className="absolute rounded-full"
              style={{
                width: 250, height: 250,
                top: 350, left: -50,
                background: 'radial-gradient(circle, rgba(150, 220, 220, 0.5) 0%, transparent 70%)',
                filter: 'blur(80px)',
              }}
            />
            <div
              className="absolute rounded-full"
              style={{
                width: 130, height: 130,
                top: 70, left: 14,
                background: 'radial-gradient(circle, rgba(255, 182, 193, 0.4) 0%, transparent 70%)',
                filter: 'blur(64px)',
              }}
            />
          </>
        ) : (
          <>
            {/* White Variant Blobs */}
            <div
              className="absolute rounded-full"
              style={{
                width: 280, height: 280,
                top: -80, right: -60,
                background: 'radial-gradient(circle, rgba(56, 211, 240, 0.45) 0%, transparent 70%)',
                filter: 'blur(60px)',
              }}
            />
            <div
              className="absolute rounded-full"
              style={{
                width: 320, height: 450,
                top: '15%', left: -100,
                background: 'radial-gradient(circle, rgba(255, 150, 200, 0.5) 0%, transparent 70%)',
                filter: 'blur(80px)',
              }}
            />
            <div
              className="absolute rounded-full"
              style={{
                width: 180, height: 180,
                top: '45%', right: -40,
                background: 'radial-gradient(circle, rgba(56, 211, 240, 0.25) 0%, transparent 70%)',
                filter: 'blur(60px)',
              }}
            />
            <div
              className="absolute rounded-full"
              style={{
                width: 350, height: 350,
                bottom: -120, right: -40,
                background: 'radial-gradient(circle, rgba(56, 211, 240, 0.4) 0%, transparent 70%)',
                filter: 'blur(90px)',
              }}
            />
            <div
              className="absolute rounded-full"
              style={{
                width: 200, height: 200,
                bottom: -50, left: -30,
                background: 'radial-gradient(circle, rgba(255, 150, 200, 0.45) 0%, transparent 70%)',
                filter: 'blur(70px)',
              }}
            />
          </>
        )}
      </div>

      {/* Content */}
      <div className="relative z-10">{children}</div>
    </div>
  );
};

// ============================================================================
// GLASS CARD COMPONENT
// ============================================================================

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  hoverable?: boolean;
  onClick?: () => void;
}

const GlassCard = ({ children, className = '', hoverable = false, onClick }: GlassCardProps) => {
  return (
    <div
      className={`
        bg-white/70 backdrop-blur-xl
        border border-white/30 
        rounded-2xl p-4
        shadow-lg
        ${hoverable ? 'hover:bg-white/80 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer' : ''}
        ${className}
      `}
      onClick={onClick}
    >
      {children}
    </div>
  );
};

// ============================================================================
// DEMO CONTENT
// ============================================================================

const WhiteVariantContent = () => (
  <div className="p-6 max-w-sm mx-auto">
    <div className="text-center mb-6">
      <h1 className="text-xl font-bold text-gray-800 mb-2">Choose Your Country</h1>
      <p className="text-sm text-gray-600">Select your preferred study destination</p>
    </div>
    
    <div className="grid grid-cols-3 gap-3 mb-6">
      {['🇺🇸 USA', '🇬🇧 UK', '🇨🇦 Canada', '🇦🇺 Australia', '🇩🇪 Germany', '🇫🇷 France'].map((country) => (
        <GlassCard key={country} hoverable className="text-center py-3">
          <span className="text-xs">{country}</span>
        </GlassCard>
      ))}
    </div>

    <button className="w-full bg-red-500 hover:bg-red-600 text-white py-3 rounded-full font-semibold transition-colors text-sm">
      Next
    </button>

    <div className="mt-8 pt-6 border-t border-gray-200/50">
      <div className="grid grid-cols-3 gap-2 text-center">
        <div>
          <div className="text-sm font-bold text-gray-800">12,000+</div>
          <div className="text-[10px] text-gray-500">Students</div>
        </div>
        <div>
          <div className="text-sm font-bold text-gray-800">3,00,000+</div>
          <div className="text-[10px] text-gray-500">Options</div>
        </div>
        <div>
          <div className="text-sm font-bold text-gray-800">2,180</div>
          <div className="text-[10px] text-gray-500">Universities</div>
        </div>
      </div>
    </div>
  </div>
);

const PastelVariantContent = () => (
  <div className="p-6 max-w-sm mx-auto">
    <div className="text-center mb-6">
      <h1 className="text-xl font-bold text-gray-800 mb-2">Almost There!</h1>
      <p className="text-sm text-gray-600">Fill in your details to complete registration</p>
    </div>
    
    <GlassCard className="mb-6">
      <div className="space-y-3">
        <input
          type="text"
          placeholder="Full Name"
          className="w-full px-4 py-2.5 rounded-lg border border-gray-200 focus:border-cyan-400 focus:outline-none text-sm bg-white/80"
        />
        <input
          type="email"
          placeholder="Email Address"
          className="w-full px-4 py-2.5 rounded-lg border border-gray-200 focus:border-cyan-400 focus:outline-none text-sm bg-white/80"
        />
        <input
          type="tel"
          placeholder="Phone Number"
          className="w-full px-4 py-2.5 rounded-lg border border-gray-200 focus:border-cyan-400 focus:outline-none text-sm bg-white/80"
        />
      </div>
    </GlassCard>

    <button className="w-full bg-red-500 hover:bg-red-600 text-white py-3 rounded-full font-semibold transition-colors text-sm">
      Submit
    </button>

    <div className="mt-8 pt-6 border-t border-white/30">
      <div className="grid grid-cols-3 gap-2 text-center">
        <div>
          <div className="text-sm font-bold text-gray-800">100%</div>
          <div className="text-[10px] text-gray-500">Transparent</div>
        </div>
        <div>
          <div className="text-sm font-bold text-gray-800">500+</div>
          <div className="text-[10px] text-gray-500">Events</div>
        </div>
        <div>
          <div className="text-sm font-bold text-gray-800">12+</div>
          <div className="text-[10px] text-gray-500">Years Exp</div>
        </div>
      </div>
    </div>
  </div>
);

// ============================================================================
// MAIN APP
// ============================================================================

export default function GradientBackgroundDemo() {
  const [variant, setVariant] = useState<GradientVariant>('white');

  return (
    <div className="min-h-screen">
      {/* Variant Toggle */}
      <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50">
        <div className="bg-white/90 backdrop-blur-sm rounded-full shadow-lg p-1 flex gap-1">
          <button
            onClick={() => setVariant('white')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
              variant === 'white'
                ? 'bg-cyan-500 text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            White
          </button>
          <button
            onClick={() => setVariant('pastel')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
              variant === 'pastel'
                ? 'bg-purple-500 text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Pastel
          </button>
        </div>
      </div>

      {/* Gradient Background with Content */}
      <GradientBackground variant={variant}>
        <div className="pt-16">
          {variant === 'white' ? <WhiteVariantContent /> : <PastelVariantContent />}
        </div>
      </GradientBackground>
    </div>
  );
}
