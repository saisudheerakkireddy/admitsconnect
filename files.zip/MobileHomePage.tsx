import React from 'react';
import { useNavigate } from 'react-router-dom';
import './MobileHomePage.css';

// ============================================
// TYPES
// ============================================

interface TagItem {
  id: string;
  label: string;
}

interface StatItem {
  id: string;
  icon: string;
  value: string;
  label: string;
}

interface ServiceLink {
  id: string;
  prefix: string;
  suffix: string;
  href: string;
}

// ============================================
// DATA
// ============================================

const TAGS: TagItem[] = [
  { id: 'tag-1', label: 'Faster Offer' },
  { id: 'tag-2', label: 'Course with Internships' },
  { id: 'tag-3', label: 'High Offer Acceptance-Rate' },
  { id: 'tag-4', label: 'Affordable University' },
  { id: 'tag-5', label: 'Guaranteed Scholarship' },
  { id: 'tag-6', label: 'Trending Courses' },
  { id: 'tag-7', label: 'Popular Cities' },
  { id: 'tag-8', label: 'Graduate Jobs' },
  { id: 'tag-9', label: 'High Ranking Universities' },
  { id: 'tag-10', label: 'Outstanding Facilities' },
  { id: 'tag-11', label: 'English Test Waiver' },
  { id: 'tag-12', label: 'Low Tuition Deposit' },
  { id: 'tag-13', label: 'Backlog Acceptance' },
  { id: 'tag-14', label: 'MOI Acceptable' },
  { id: 'tag-15', label: 'Professional Accreditations' },
  { id: 'tag-16', label: 'Culture and Social Experience' },
  { id: 'tag-17', label: 'Interactive Learning' },
  { id: 'tag-18', label: 'No Interview Required' },
  { id: 'tag-19', label: 'Affordable Living' },
  { id: 'tag-20', label: 'Career Upskilling' },
  { id: 'tag-21', label: 'Quick Education Loans' },
  { id: 'tag-22', label: 'Accommodation' },
  { id: 'tag-23', label: 'Part Time Jobs' },
  { id: 'tag-24', label: 'Pre-Departure' },
  { id: 'tag-25', label: 'Forex Exchange' },
  { id: 'tag-26', label: 'Destination - Arrival pickup' },
  { id: 'tag-27', label: 'On - Arrival registrations' },
  { id: 'tag-28', label: 'Internship (in-line to Subject area)' },
  { id: 'tag-29', label: 'Part-time jobs (in-line to academics / work experience)' },
  { id: 'tag-30', label: 'Resume/CV marketing for Professional jobs' },
];

const STATS: StatItem[] = [
  { id: 'stat-1', icon: 'students', value: '12,000+', label: 'Students\nHelped' },
  { id: 'stat-2', icon: 'options', value: '3,00,000+', label: 'Study\nOptions' },
  { id: 'stat-3', icon: 'universities', value: '2,180', label: 'Global\nUniversities' },
  { id: 'stat-4', icon: 'transparent', value: '100%', label: 'Transparent\nProcess' },
  { id: 'stat-5', icon: 'events', value: '500+', label: 'Global\nEvents' },
  { id: 'stat-6', icon: 'sessions', value: '1,200+', label: 'Virtual\nsessions' },
  { id: 'stat-7', icon: 'satisfaction', value: '100%', label: 'Student\nSatisfaction' },
  { id: 'stat-8', icon: 'destinations', value: '20+', label: 'Study\nDestinations' },
  { id: 'stat-9', icon: 'experience', value: '12+', label: "Year's\nExperience" },
];

const SERVICE_LINKS: ServiceLink[] = [
  { id: 'service-1', prefix: 'ApplyUni', suffix: 'Now', href: '/apply' },
  { id: 'service-2', prefix: 'ApplyUni', suffix: 'Loans', href: '/loans' },
  { id: 'service-3', prefix: 'ApplyUni', suffix: 'Homes', href: '/homes' },
  { id: 'service-4', prefix: 'ApplyUni', suffix: 'Jobs', href: '/jobs' },
];

const FOOTER_LINKS = {
  explore: [
    { label: 'About Us', href: '/about' },
    { label: 'EXPLORE', href: '/explore' },
    { label: 'AI Student Advisor', href: '/advisor' },
  ],
  legal: [
    { label: 'T&C', href: '/terms' },
    { label: 'Privacy Policy', href: '/privacy' },
    { label: 'Refund Policy', href: '/refund' },
    { label: 'Anti-Fraud Policy', href: '/anti-fraud' },
    { label: 'Grievance', href: '/grievance' },
  ],
};

const CONTACT_INFO = {
  phone: [
    { label: '+44 773 45 66688 UK', href: 'tel:+447734566688' },
    { label: '+91 970 45 66688 IN', href: 'tel:+919704566688' },
  ],
  email: { label: 'support@applyuninow.com', href: 'mailto:support@applyuninow.com' },
};

// ============================================
// SUB-COMPONENTS
// ============================================

const StarLogo: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    className={className}
    viewBox="0 0 69 66" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
  >
    <path 
      d="M34.5 0L42.5 22H66L47 36L55 58L34.5 44L14 58L22 36L3 22H26.5L34.5 0Z" 
      fill="url(#starGradient)"
    />
    <defs>
      <linearGradient id="starGradient" x1="3" y1="0" x2="66" y2="58" gradientUnits="userSpaceOnUse">
        <stop stopColor="#1E417C"/>
        <stop offset="1" stopColor="#C22032"/>
      </linearGradient>
    </defs>
  </svg>
);

const MenuIcon: React.FC<{ className?: string; onClick?: () => void }> = ({ className, onClick }) => (
  <svg 
    className={className}
    onClick={onClick}
    viewBox="0 0 15 10" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
  >
    <line x1="0" y1="1" x2="15" y2="1" stroke="black" strokeWidth="2"/>
    <line x1="0" y1="5" x2="15" y2="5" stroke="black" strokeWidth="2"/>
    <line x1="0" y1="9" x2="15" y2="9" stroke="black" strokeWidth="2"/>
  </svg>
);

const ProfileIcon: React.FC<{ className?: string; onClick?: () => void }> = ({ className, onClick }) => (
  <svg 
    className={className}
    onClick={onClick}
    viewBox="0 0 20 20" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
  >
    <circle cx="10" cy="6" r="4" stroke="#C22032" strokeWidth="1.5" fill="none"/>
    <path d="M2 18c0-4 4-6 8-6s8 2 8 6" stroke="#C22032" strokeWidth="1.5" fill="none"/>
  </svg>
);

const StatIcon: React.FC<{ type: string; className?: string }> = ({ type, className }) => {
  const icons: Record<string, JSX.Element> = {
    students: (
      <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="12" cy="10" r="5" stroke="#C22032" strokeWidth="2"/>
        <circle cx="22" cy="10" r="4" stroke="#C22032" strokeWidth="1.5"/>
        <path d="M4 26c0-5 4-8 8-8 2 0 4 0.5 5.5 1.5" stroke="#C22032" strokeWidth="2"/>
        <path d="M18 26c0-4 3-6 6-6s6 2 6 6" stroke="#C22032" strokeWidth="1.5"/>
      </svg>
    ),
    options: (
      <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="4" y="4" width="10" height="10" rx="2" stroke="#C22032" strokeWidth="2"/>
        <rect x="18" y="4" width="10" height="10" rx="2" stroke="#C22032" strokeWidth="2"/>
        <rect x="4" y="18" width="10" height="10" rx="2" stroke="#C22032" strokeWidth="2"/>
        <rect x="18" y="18" width="10" height="10" rx="2" stroke="#C22032" strokeWidth="2"/>
      </svg>
    ),
    universities: (
      <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M16 2L2 10L16 18L30 10L16 2Z" stroke="#C22032" strokeWidth="2"/>
        <path d="M6 14V24L16 30L26 24V14" stroke="#C22032" strokeWidth="2"/>
        <line x1="16" y1="18" x2="16" y2="30" stroke="#C22032" strokeWidth="2"/>
      </svg>
    ),
    transparent: (
      <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="16" cy="16" r="12" stroke="#C22032" strokeWidth="2"/>
        <path d="M10 16L14 20L22 12" stroke="#C22032" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
    events: (
      <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="4" y="6" width="24" height="22" rx="2" stroke="#C22032" strokeWidth="2"/>
        <line x1="4" y1="12" x2="28" y2="12" stroke="#C22032" strokeWidth="2"/>
        <line x1="10" y1="4" x2="10" y2="8" stroke="#C22032" strokeWidth="2" strokeLinecap="round"/>
        <line x1="22" y1="4" x2="22" y2="8" stroke="#C22032" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    ),
    sessions: (
      <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="4" y="8" width="24" height="18" rx="2" stroke="#C22032" strokeWidth="2"/>
        <circle cx="16" cy="17" r="4" stroke="#C22032" strokeWidth="2"/>
        <path d="M14 17L16 19L18 15" stroke="#C22032" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
    satisfaction: (
      <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="16" cy="16" r="12" stroke="#C22032" strokeWidth="2"/>
        <circle cx="11" cy="13" r="2" fill="#C22032"/>
        <circle cx="21" cy="13" r="2" fill="#C22032"/>
        <path d="M10 20C12 23 20 23 22 20" stroke="#C22032" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    ),
    destinations: (
      <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="16" cy="12" r="4" stroke="#C22032" strokeWidth="2"/>
        <path d="M16 2C10 2 6 7 6 12C6 18 16 30 16 30C16 30 26 18 26 12C26 7 22 2 16 2Z" stroke="#C22032" strokeWidth="2"/>
      </svg>
    ),
    experience: (
      <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M16 4L18 12H26L20 17L22 25L16 20L10 25L12 17L6 12H14L16 4Z" stroke="#C22032" strokeWidth="2"/>
      </svg>
    ),
  };
  
  return <div className={className}>{icons[type] || icons.students}</div>;
};

// ============================================
// MAIN COMPONENT
// ============================================

const MobileHomePage: React.FC = () => {
  const navigate = useNavigate();

  const handleNextClick = () => {
    navigate('/country-selection');
  };

  const handleTagClick = (tagId: string) => {
    console.log('Tag clicked:', tagId);
    // Could filter/highlight or navigate based on tag
  };

  return (
    <div className="home-page">
      {/* Background Design Elements */}
      <div className="background-design">
        <div className="background-ellipse background-ellipse--1" />
        <div className="background-ellipse background-ellipse--2" />
        <div className="background-ellipse background-ellipse--3" />
        <div className="background-ellipse background-ellipse--4" />
      </div>

      {/* Header */}
      <header className="header">
        <div className="logo">
          <StarLogo className="logo__icon" />
          <span className="logo__text">One</span>
        </div>
        
        {/* Desktop Navigation - Service Links */}
        <nav className="nav-services">
          {SERVICE_LINKS.map((link) => (
            <a 
              key={link.id} 
              href={link.href} 
              className="nav-services__link"
            >
              <span className="nav-services__link-prefix">{link.prefix}</span>
              <span className="nav-services__link-suffix">{link.suffix}</span>
            </a>
          ))}
        </nav>
        
        <div className="header__actions">
          <ProfileIcon className="profile-icon" />
          <MenuIcon className="menu-icon" />
        </div>
      </header>

      {/* Main Content */}
      <main className="main-content">
        {/* Hero Section */}
        <section className="hero">
          <h1 className="hero__headline">
            Four Services <span className="hero__headline--highlight">+</span> One Mission<span className="hero__headline--highlight">:</span>
            <br />
            <strong>Empowering global talent</strong>.
          </h1>
          <p className="hero__subheadline">
            Not just study options but
            <br />
            Experience the future-ready-courses.
          </p>
        </section>

        {/* Tags Section */}
        <section className="tags-section">
          {TAGS.map((tag) => (
            <button
              key={tag.id}
              className="tag"
              onClick={() => handleTagClick(tag.id)}
              type="button"
            >
              <span className="tag__text">{tag.label}</span>
            </button>
          ))}
          
          {/* Next Button */}
          <div className="next-button-wrapper">
            <button 
              className="next-button" 
              onClick={handleNextClick}
              type="button"
            >
              <span className="next-button__text">Next</span>
            </button>
          </div>
        </section>

        {/* Divider */}
        <div className="divider" />

        {/* Stats Section */}
        <section className="stats-section">
          <div className="stats-row">
            {STATS.slice(0, 3).map((stat) => (
              <div key={stat.id} className="stat-item">
                <StatIcon type={stat.icon} className="stat-item__icon" />
                <p className="stat-item__text">
                  {stat.value}
                  <br />
                  {stat.label.split('\n').map((line, i) => (
                    <React.Fragment key={i}>
                      {line}
                      {i < stat.label.split('\n').length - 1 && <br />}
                    </React.Fragment>
                  ))}
                </p>
              </div>
            ))}
          </div>
          <div className="stats-row">
            {STATS.slice(3, 6).map((stat) => (
              <div key={stat.id} className="stat-item">
                <StatIcon type={stat.icon} className="stat-item__icon" />
                <p className="stat-item__text">
                  {stat.value}
                  <br />
                  {stat.label.split('\n').map((line, i) => (
                    <React.Fragment key={i}>
                      {line}
                      {i < stat.label.split('\n').length - 1 && <br />}
                    </React.Fragment>
                  ))}
                </p>
              </div>
            ))}
          </div>
          <div className="stats-row">
            {STATS.slice(6, 9).map((stat) => (
              <div key={stat.id} className="stat-item">
                <StatIcon type={stat.icon} className="stat-item__icon" />
                <p className="stat-item__text">
                  {stat.value}
                  <br />
                  {stat.label.split('\n').map((line, i) => (
                    <React.Fragment key={i}>
                      {line}
                      {i < stat.label.split('\n').length - 1 && <br />}
                    </React.Fragment>
                  ))}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Footer */}
        <footer className="footer">
          <nav className="footer-nav">
            <div className="footer-nav__row">
              {FOOTER_LINKS.explore.map((link) => (
                <a key={link.label} href={link.href} className="footer-nav__link">
                  {link.label}
                </a>
              ))}
            </div>
            <div className="footer-nav__row">
              {FOOTER_LINKS.legal.map((link) => (
                <a key={link.label} href={link.href} className="footer-nav__link">
                  {link.label}
                </a>
              ))}
            </div>
          </nav>
          
          <div className="footer-contact">
            <span className="footer-contact__title">Quick Question?</span>
            {CONTACT_INFO.phone.map((phone) => (
              <a key={phone.label} href={phone.href} className="footer-contact__item">
                {phone.label}
              </a>
            ))}
            <a href={CONTACT_INFO.email.href} className="footer-contact__item">
              {CONTACT_INFO.email.label}
            </a>
          </div>
          
          <p className="footer__credit">
            Crafted by AUN Tech Consulting Pvt. Ltd.
          </p>
        </footer>
      </main>
    </div>
  );
};

export default MobileHomePage;
