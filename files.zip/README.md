# AdmitsConnect Home Page - Figma Implementation

## 📐 Design Specifications

This implementation is pixel-perfect to the Figma design:
- **File**: `Zx86jWsAArauxH2Ntm3MoN`
- **Breakpoints**: 393px (Mobile) → 768px (Tablet) → 1920px (Desktop)

## 📁 Files Included

```
src/
├── components/
│   └── MobileHomePage/
│       ├── index.ts              # Component export
│       ├── MobileHomePage.tsx    # React component
│       └── MobileHomePage.css    # Responsive styles
└── styles/
    ├── variables.css             # Design tokens
    └── global.css                # Base styles + font imports
```

## 🚀 Integration Steps

### 1. Copy Files to Your Project

```bash
# Copy component files
cp -r src/components/MobileHomePage/* YOUR_PROJECT/src/components/MobileHomePage/

# Copy style files
cp src/styles/variables.css YOUR_PROJECT/src/styles/
cp src/styles/global.css YOUR_PROJECT/src/styles/
```

### 2. Import Global Styles

In your `App.tsx` or `index.tsx`:

```tsx
import './styles/global.css';
```

### 3. Add Route

In your router configuration:

```tsx
import MobileHomePage from './components/MobileHomePage';

// In your routes
<Route path="/" element={<MobileHomePage />} />
```

## 🎨 Design Tokens Reference

### Colors
| Token | Value | Usage |
|-------|-------|-------|
| `--color-primary-blue` | `#1E417C` | Logo, links |
| `--color-primary-red` | `#C22032` | CTA buttons, accents |
| `--color-text-secondary` | `#505050` | Body text |
| `--gradient-brand` | `linear-gradient(160.59deg, #EE1113 0.91%, #7403FA 96.74%)` | Hero subheadline, footer credit |

### Typography Scale

| Breakpoint | Tag Text | Body Text | Headline |
|------------|----------|-----------|----------|
| Mobile (393px) | 8px | 12px | 12px |
| Tablet (768px) | 12px | 15px | 16px |
| Desktop (1920px) | 15px | 15px | 20px |

### Spacing

| Token | Value | Usage |
|-------|-------|-------|
| `--tag-gap` | 10px → 20px | Gap between tags |
| `--section-gap` | 40px → 80px | Section margins |
| `--tag-height-mobile` | 28px | Tag pill height |
| `--tag-height-tablet` | 40px | Tag pill height |
| `--tag-height-desktop` | 50px | Tag pill height |

## 📱 Responsive Behavior

### Mobile (< 768px)
- Hamburger menu visible
- Service links hidden
- Stats in 3x3 grid
- Tags wrap naturally

### Tablet (768px - 1199px)
- Hamburger menu visible
- Service links hidden
- Stats in 3x3 grid
- Larger tag pills

### Desktop (1200px+)
- Inline navigation (ApplyUniNow, ApplyUniLoans, etc.)
- Stats in single horizontal row (9 columns)
- Full-width layout
- Larger typography

## ⚡ Key Features

1. **Glassmorphism Tags**: Multi-layer inset shadows with backdrop blur
2. **Gradient Text**: Brand gradient applied to hero subheadline
3. **Responsive Grid**: Stats section transforms from 3x3 to 1x9
4. **Pixel-Perfect Spacing**: Exact values from Figma

## 🔄 Customization

### Change Brand Colors

Edit `src/styles/variables.css`:

```css
:root {
  --color-primary-blue: #YOUR_BLUE;
  --color-primary-red: #YOUR_RED;
  --gradient-start: #YOUR_GRADIENT_START;
  --gradient-end: #YOUR_GRADIENT_END;
}
```

### Add/Remove Tags

Edit `MobileHomePage.tsx`:

```tsx
const TAGS: TagItem[] = [
  { id: 'tag-1', label: 'Your New Tag' },
  // ...
];
```

## 📋 Figma Node References

| Component | Mobile Node | Tablet Node | Desktop Node |
|-----------|-------------|-------------|--------------|
| Home Page | `138:3928` | `305:6068` | `630:6492` |

## 🐛 Known Considerations

1. **Font Loading**: Ensure Google Fonts are loaded before render to prevent FOUT
2. **IE11**: Not supported (uses CSS custom properties, flexbox gap)
3. **Safari**: `backdrop-filter` may need `-webkit-` prefix (included)

## 📞 Support

Generated from Figma using MCP on: 2026-01-03
